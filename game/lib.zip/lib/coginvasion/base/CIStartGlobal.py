"""
  
  Filename: CIStartGlobal.py
  Created by: blach (??July14)
  
"""

import sys
sys.dont_write_bytecode = True

import lib.coginvasion.base.CIStart
