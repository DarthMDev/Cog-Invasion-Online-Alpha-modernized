"""

  Filename: ItemType.py
  Created by: DecodedLogic (13Jul15)
  
"""

class ItemType:
    GAG, UPGRADE, HEAL = range(3)