"""

  Filename: BattleShop.py
  Created by: DecodedLogic (14Jul15)

"""

from direct.directnotify.DirectNotifyGlobal import directNotify
from lib.coginvasion.shop.Shop import Shop
from lib.coginvasion.shop.ItemType import ItemType

class BattleShop(Shop):
    notify = directNotify.newCategory('BattleShop')
    
    def __init__(self, distShop, doneEvent):
        Shop.__init__(self, distShop, doneEvent)
        self.originalUpgrades = []
        self.distShop.addItem('Pie Turret', ItemType.UPGRADE, 200, 'phase_3.5/maps/cannon-icon.png', upgradeID = 0, maxUpgrades = 1)
        self.distShop.addItem('+20 Laff', ItemType.HEAL, 100, 'phase_3.5/maps/ice-cream-cone.png', heal = 20, showTitle = True)
        self.items = self.distShop.getItems()
        
    def purchaseItem(self, item):
        self.originalUpgrades.append(base.localAvatar.getPUInventory()[0])
        Shop.purchaseItem(self, item)
        
    def confirmPurchase(self):
        Shop.confirmPurchase(self)
        self.distShop.sendUpdate('confirmPurchase', [[base.localAvatar.getPUInventory()[0]], base.localAvatar.getMoney()])
        
    def cancelPurchase(self):
        Shop.cancelPurchase(self)
        if base.localAvatar.getMyBattle().getTurretManager().myTurret and len(self.originalUpgrades) > 0:
            base.localAvatar.getMyBattle().getTurretManager().destroyGui()
        
    def enter(self):
        Shop.enter(self)
        
    def exit(self):
        Shop.exit(self)
        self.originalUpgrades = []
        
    def update(self):
        Shop.update(self)