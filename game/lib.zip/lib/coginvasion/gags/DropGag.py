"""

  Filename: DropGag.py
  Created by: DecodedLogic (16Jul15)
  
"""

from lib.coginvasion.gags.Gag import Gag
from lib.coginvasion.gags.GagType import GagType
from lib.coginvasion.gags.GagState import GagState
from lib.coginvasion.globals import CIGlobals
from direct.directnotify.DirectNotifyGlobal import directNotify
from direct.interval.IntervalGlobal import Sequence, ActorInterval, Func, SoundInterval, Wait, LerpScaleInterval
from direct.task.Task import Task
from panda3d.core import CollisionNode, CollisionHandlerEvent, CollisionHandlerQueue, CollisionHandlerFloor, CollisionRay, CollisionSphere, BitMask32, Point3
import abc

class DropGag(Gag):
    notify = directNotify.newCategory('DropGag')
    
    def __init__(self, name, model, anim, damage, hitSfx, missSfx, scale, playRate):
        Gag.__init__(self, name, model, damage, GagType.DROP, hitSfx, anim = anim, playRate = playRate, scale = scale, autoRelease = True)
        self.missSfx = None
        self.rejectSoundPath = 'phase_4/audio/sfx/ring_miss.mp3'
        self.buttonSoundPath = 'phase_5/audio/sfx/AA_drop_trigger_box.mp3'
        self.fallSoundPath = 'phase_5/audio/sfx/incoming_whistleALT.mp3'
        self.fallSoundInterval = None
        self.rejectSfx = None
        self.buttonSfx = None
        self.fallSfx = None
        self.audio3D = self.getAudio3D()
        self.button = None
        self.buttonAnim = 'push-button'
        self.moveShadowTaskName = 'Move Shadow'
        self.lHandJoint = None
        self.chooseLocFrame = 34
        self.completeFrame = 77
        self.collHandlerQ = CollisionHandlerQueue()
        self.collHandlerF = CollisionHandlerFloor()
        self.cameraNode = None
        self.cameraRay = None
        self.cameraNP = None
        self.posShadow = None
        self.minDistance = 10
        self.maxDistance = 50
        self.fallDuration = 0.75
        self.tButtonPress = 2.44
        self.dropLoc = None
        if game.process == 'client':
            self.missSfx = self.audio3D.loadSfx(missSfx)
            self.rejectSfx = self.audio3D.loadSfx(self.rejectSoundPath)
            self.buttonSfx = self.audio3D.loadSfx(self.buttonSoundPath)
            self.fallSfx = self.audio3D.loadSfx(self.fallSoundPath)
            
    def buildButton(self):
        self.cleanupButton()
        self.button = loader.loadModel('phase_3.5/models/props/button.bam')
        
    def cleanupButton(self):
        if self.button:
            self.button.removeNode()
            
    def buildShadow(self):
        self.cleanupShadow()
        self.posShadow = loader.loadModel('phase_3/models/props/square_drop_shadow.bam')
    
    def cleanupShadow(self):
        if self.posShadow:
            self.posShadow.removeNode()
            self.posShadow = None
            if self.cameraNode:
                self.cameraNP.removeNode()
                self.cameraNP = None
                self.cameraNode = None
                self.cameraRay = None
            
    def startLocationSeek(self):
        if self.avatar == base.localAvatar:
            self.buildShadow()
            
            pos = base.localAvatar.getPos(render)
            self.posShadow.reparentTo(render)
            self.posShadow.setPos(pos.getX(), pos.getY() + 5, pos.getZ() + 2)
            
            self.cameraNode = CollisionNode('coll_camera')
            self.cameraNode.setFromCollideMask(CIGlobals.WallBitmask)
            self.cameraRay = CollisionRay()
            self.cameraNode.addSolid(self.cameraRay)
            self.cameraNP = camera.attachNewNode(self.cameraNode)
            base.cTrav.addCollider(self.cameraNP, self.collHandlerQ)
            taskMgr.add(self.moveShadow, self.moveShadowTaskName)
            base.localAvatar.acceptOnce('mouse1', self.prepareDrop)
            
    def prepareDrop(self):
        if base.localAvatar.getDistance(self.posShadow) >= self.minDistance and base.localAvatar.getDistance(self.posShadow) <= self.maxDistance:
            self.dropLoc = self.posShadow.getPos()
            self.cleanupShadow()
            taskMgr.remove(self.moveShadowTaskName)
            base.localAvatar.sendUpdate('setDropLoc', [self.dropLoc.getX(), self.dropLoc.getY(), self.dropLoc.getZ()])
            base.localAvatar.releaseGag()
        else:
            SoundInterval(self.rejectSfx).start()
            base.localAvatar.acceptOnce('mouse1', self.prepareDrop)
            
    def completeDrop(self):
        if game.process != 'client': return
        numFrames = base.localAvatar.getNumFrames(self.buttonAnim)
        ActorInterval(self.avatar, self.buttonAnim, startFrame = self.completeFrame, endFrame = numFrames,
                      playRate = self.playRate).start()
        self.reset()
        self.cleanupButton()
        if base.localAvatar == self.avatar:
            base.localAvatar.enablePieKeys()
            
    def setEndPos(self, x, y, z):
        self.dropLoc = Point3(x, y, z)
            
    def moveShadow(self, task):
        if base.mouseWatcherNode.hasMouse():
            def PointAtZ(z, point, vec):
                if vec.getZ() != 0:
                    return point + vec * ((z-point.getZ()) / vec.getZ())
                else:
                    return self.posShadow.getPos()
            mouse = base.mouseWatcherNode.getMouse()
            self.cameraRay.setFromLens(base.camNode, mouse.getX(), mouse.getY())
            nearPoint = render.getRelativePoint(camera, self.cameraRay.getOrigin())
            nearVec = render.getRelativeVector(camera, self.cameraRay.getDirection())
            self.posShadow.setPos(PointAtZ(.5, nearPoint, nearVec))
            self.posShadow.setZ(base.localAvatar.getPos(render).getZ() + 0.5)
        return Task.cont
        
    def start(self):
        super(DropGag, self).start()
        self.buildButton()
        if not self.lHandJoint:
            self.lHandJoint = self.avatar.find('**/def_joint_left_hold')
        self.button.reparentTo(self.lHandJoint)
        Sequence(ActorInterval(self.avatar, self.buttonAnim, startFrame = 0, endFrame = self.chooseLocFrame,
                               playRate = self.playRate), Func(self.startLocationSeek)).start()
                               
    def unEquip(self):
        Gag.unEquip(self)
        self.cleanupShadow()
        if self.avatar:
            self.avatar.ignore('mouse1')
        taskMgr.remove(self.moveShadowTaskName)
        if self.state != GagState.LOADED:
            self.completeDrop()
        
    def buildCollisions(self):
        gagSph = CollisionSphere(0, 1.5, 0, 2)
        gagSensor = CollisionNode('gagSensor')
        gagSensor.addSolid(gagSph)
        sensorNP = self.gag.attachNewNode(gagSensor)
        sensorNP.setCollideMask(BitMask32(0))
        sensorNP.node().setFromCollideMask(CIGlobals.WallBitmask | CIGlobals.FloorBitmask)
        event = CollisionHandlerEvent()
        event.set_in_pattern("%fn-into")
        event.set_out_pattern("%fn-out")
        base.cTrav.add_collider(sensorNP, event)
        self.avatar.acceptOnce('gagSensor-into', self.onCollision)
        
    def onCollision(self, entry):
        intoNP = entry.getIntoNodePath()
        avNP = intoNP.getParent()
        hitCog = False
        self.fallSoundInterval.finish()
        self.fallSoundInterval = None
        shrinkTrack = Sequence()
        if self.avatar.doId == base.localAvatar.doId:
            for key in base.cr.doId2do.keys():
                obj = base.cr.doId2do[key]
                if obj.__class__.__name__ == "DistributedSuit":
                    if obj.getKey() == avNP.getKey():
                        if obj.getHealth() > 0:
                            self.avatar.sendUpdate('suitHitByPie', [obj.doId, self.getID()])
                            hitCog = True
        if hitCog:
            SoundInterval(self.hitSfx, node = self.gag).start()
            shrinkTrack.append(Wait(0.5))
        else:
            SoundInterval(self.missSfx, node = self.gag).start()
        shrinkTrack.append(LerpScaleInterval(self.gag, 0.3, Point3(0.01, 0.01, 0.01), startScale = self.gag.getScale()))
        shrinkTrack.append(Func(self.cleanupGag))
        shrinkTrack.start()
       
    @abc.abstractmethod 
    def startDrop(self):
        pass
                               
    def release(self):
        self.build()
        Sequence(ActorInterval(self.avatar, self.buttonAnim, startFrame = self.chooseLocFrame, 
                               endFrame = self.completeFrame, playRate = self.playRate), Func(self.startDrop)).start()
        self.fallSoundInterval = SoundInterval(self.fallSfx, node = self.avatar)
        Sequence(Wait(0.6), SoundInterval(self.buttonSfx, node = self.avatar), self.fallSoundInterval).start()