"""

  Filename: GagType.py
  Created by: DecodedLogic (07Jul15)
  
"""

class GagType:
    THROW, SQUIRT, TRAP, DROP, TOON_UP = range(5)