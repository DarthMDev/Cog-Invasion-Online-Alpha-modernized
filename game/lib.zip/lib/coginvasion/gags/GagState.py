"""

  Filename: GagState.py
  Created by: DecodedLogic (07Jul15)
  
"""

class GagState:
    LOADED, START, RELEASED = range(3)