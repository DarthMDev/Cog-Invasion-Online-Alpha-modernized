"""

  Filename: SmallPouch.py
  Created by: DecodedLogic (07Jul15)
  
"""

from lib.coginvasion.gags.backpack.Backpack import Backpack
from lib.coginvasion.globals import CIGlobals

class SmallPouch(Backpack):
    
    def __init__(self):
        Backpack.__init__(self)
        self.setGags({self.gagMgr.getGagByName(CIGlobals.BambooCane) : [7, 7], 
                      self.gagMgr.getGagByName(CIGlobals.WeddingCake) : [3, 3], 
                      self.gagMgr.getGagByName(CIGlobals.GrandPiano) : [15, 15], 
                      self.gagMgr.getGagByName(CIGlobals.WholeFruitPie) : [12, 12]})