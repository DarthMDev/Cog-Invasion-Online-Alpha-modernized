"""

  Filename: Backpack.py
  Created by: DecodedLogic (07Jul15)
  
"""

from lib.coginvasion.gags.GagManager import GagManager
from abc import ABCMeta
import numbers

class Backpack:
    
    def __init__(self):
        __metaclass__ = ABCMeta
        self.gags = None
        self.index = 3
        self.currentGag = None
        self.gagMgr = GagManager()
        self.gagGUI = None
        
    def setup(self, avatar):
        for gag in self.gags.keys():
            gag.setAvatar(avatar)
            
    def setGagGUI(self, gui):
        self.gagGUI = gui
    
    def getGagGUI(self):
        return self.gagGUI
        
    def setGags(self, gags):
        self.gags = gags
        
    def getGags(self):
        return self.gags
    
    def getGagByIndex(self, index):
        return self.gags.keys()[index]
    
    def getIndexFromName(self, name):
        names = self.gags.keys()
        for gName in names:
            if gName == name:
                return self.gags.keys().index(gName)
        
    def setCurrentGag(self, arg):
        for gag in self.gags.keys():
            if gag.getName() == arg:
                self.index = self.gags.keys().index(gag)
                break
        if self.currentGag: self.currentGag.unEquip()
        self.currentGag = self.gags.keys()[self.index]
        
    def getCurrentGag(self):
        return self.currentGag
        
    def setMaxSupply(self, nMaxSupply, arg = None):
        if isinstance(arg, numbers.Number) or arg == None:
            if self.index and self.gags:
                if arg == None:
                    arg = self.index
                self.gags.values()[arg][1] = nMaxSupply
        elif isinstance(arg, str):
            if self.gags:
                for index in range(0, len(self.gags)):
                    gag = self.gags.keys()[index]
                    if gag.getName() == arg:
                        self.gags.values()[index][1] = nMaxSupply
                        break
        
    def getMaxSupply(self, arg = None):
        if isinstance(arg, numbers.Number) or arg == None:
            if self.index and self.gags:
                if arg == None:
                    arg = self.index
                return self.gags.values()[arg][1]
        elif isinstance(arg, str):
            if self.gags:
                for index in range(0, len(self.gags)):
                    gag = self.gags.keys()[index]
                    if gag.getName() == arg:
                        return self.gags.values()[index][1]
        if arg: return 0
    
    def setSupply(self, nSupply, arg = None):
        curMaxSupply = None
        index = None
        if arg == None and self.index:
            curMaxSupply = self.gags.values()[self.index][1]
            index = self.gags.keys()[self.index]
        if isinstance(arg, numbers.Number):
            if self.index and self.gags:
                curMaxSupply = self.gags.values()[arg][1]
                index = self.gags.keys()[arg]
        elif isinstance(arg, str):
            if self.gags:
                for gag, ammoTbl in self.gags.iteritems():
                    if gag.getName() == arg:
                        ammoTbl[0] = nSupply
                        curMaxSupply = ammoTbl[1]
                        index = gag
                        break
        self.gags.update({index : [nSupply, curMaxSupply]})
        if game.process == 'client' and self.gagGUI: 
            self.gagGUI.update()
        
    def getSupply(self, arg = None):
        curSupply = 0
        if arg == None:
            curSupply = self.gags.values()[self.index][0]
        if isinstance(arg, numbers.Number):
            if self.index and self.gags:
                curSupply = self.gags.values()[arg][0]
            if curSupply == None: return 0
        elif isinstance(arg, str):
            if self.gags:
                for gag, ammoTbl in self.gags.iteritems():
                    if gag.getName() == arg:
                        curSupply = ammoTbl[0]
                        break
        return curSupply
                    
    def getIndex(self):
        return self.index