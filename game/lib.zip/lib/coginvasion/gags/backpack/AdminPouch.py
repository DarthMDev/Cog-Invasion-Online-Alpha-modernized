"""

  Filename: AdminPouch.py
  Created by: DecodedLogic (15Jul15)
  
"""

from lib.coginvasion.gags.backpack.Backpack import Backpack
from lib.coginvasion.globals import CIGlobals

class AdminPouch(Backpack):
    
    def __init__(self):
        Backpack.__init__(self)
        self.setGags({self.gagMgr.getGagByName(CIGlobals.WholeCreamPie) : [255, 255], 
                      self.gagMgr.getGagByName(CIGlobals.BirthdayCake) : [255, 255], 
                      self.gagMgr.getGagByName(CIGlobals.TNT) : [255, 255], 
                      self.gagMgr.getGagByName(CIGlobals.WeddingCake) : [255, 255]})