"""

  Filename: OnlineGlobals.py
  Created by: blach (17June14)
  
  blach - Stupid and useless module; dont use.
  
"""

from direct.distributed.PyDatagram import PyDatagram
from direct.distributed.PyDatagramIterator import PyDatagramIterator
from direct.directnotify.DirectNotify import *

