"""

  Filename: HoodAI.py
  Created by: blach (20Dec14)

"""

from lib.coginvasion.distributed.HoodMgr import HoodMgr
from direct.directnotify.DirectNotifyGlobal import directNotify
from lib.coginvasion.hood import TreasureGlobals
from lib.coginvasion.hood.SZTreasurePlannerAI import SZTreasurePlannerAI

class HoodAI:
    notify = directNotify.newCategory("HoodAI")
    notify.setInfo(True)

    def __init__(self, air, zoneId, hood):
        self.air = air
        self.zoneId = zoneId
        self.hood = hood
        self.hoodMgr = HoodMgr()
        self.air.hoods[zoneId] = self
        self.treasurePlanner = None

    def startup(self):
        self.createTreasurePlanner()

    def createTreasurePlanner(self):
        spawnInfo = TreasureGlobals.treasureSpawns.get(self.zoneId)
        if not spawnInfo: return
        treasureType, healAmount, spawnPoints, spawnRate, maxTreasures = spawnInfo
        self.treasurePlanner = SZTreasurePlannerAI(self.air,
            self.zoneId, treasureType, healAmount, spawnPoints,
            spawnRate, maxTreasures)
        self.treasurePlanner.start()

    def shutdown(self):
        for obj in self.air.doId2do.values():
            obj.requestDelete()
        if self.treasurePlanner:
            self.treasurePlanner.stop()
            self.treasurePlanner.deleteAllTreasuresNow()
            self.treasurePlanner = None
        del self.zoneId
        del self.hood
        del self.hoodMgr
        del self.air.hoods[self]
        del self.air
