from lib.coginvasion.globals import CIGlobals

def getWhereName(zoneId):
	if int(str(zoneId)[1]) == 0:
		return 'playground'
	elif int(str(zoneId)[1]) > 0:
		return 'street'
	elif int(str(zoneId)[3]) > 0 or int(str(zoneId)[2]) > 0:
		return 'interior'
		
def getLoaderName(zoneId):
	if getWhereName(zoneId) == 'playground':
		return 'safeZoneLoader'
	else:
		return None
		
def getHoodId(zoneId):
	if zoneId == CIGlobals.ToontownCentralId:
		return CIGlobals.ToontownCentral
	elif zoneId == CIGlobals.MinigameAreaId:
		return CIGlobals.MinigameArea
	elif zoneId == CIGlobals.RecoverAreaId:
		return CIGlobals.RecoverArea
	elif zoneId == CIGlobals.TheBrrrghId:
		return CIGlobals.TheBrrrgh
