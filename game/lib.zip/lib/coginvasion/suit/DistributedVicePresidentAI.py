"""

  Filename: DistributedVicePresidentAI.py
  Created by: blach (27Apr15)

"""

from lib.coginvasion.avatar.DistributedAvatarAI import DistributedAvatarAI

class DistributedVicePresidentAI(DistributedAvatarAI):
	pass
