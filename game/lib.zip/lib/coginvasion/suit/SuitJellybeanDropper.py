"""

  Filename: SuitJellybeanDropper.py
  Created by: blach (22Mar15)

"""

from direct.directnotify.DirectNotifyGlobal import directNotify
from DistributedDroppableCollectableJellybeanAI import DistributedDroppableCollectableJellybeanAI
from DistributedDroppableCollectableJellybeanJarAI import DistributedDroppableCollectableJellybeanJarAI
from lib.coginvasion.globals import CIGlobals
import random

class SuitJellybeanDropper:
	notify = directNotify.newCategory("SuitJellybeanDropper")
	MAX_BEAN_VALUE = 5
	
	def __init__(self, suit):
		self.suit = suit
		
	def calculate(self):
		self.value = int(self.suit.getMaxHealth() / CIGlobals.SuitAttackDamageFactors['clipontie'])
		self.numDrops = 1
		if self.value <= self.MAX_BEAN_VALUE:
			self.beanClass = DistributedDroppableCollectableJellybeanAI
		else:
			self.beanClass = DistributedDroppableCollectableJellybeanJarAI
		if self.suit.head in ["vp"]:
			self.numDrops = 5
			self.value /= 5
			
	def drop(self):
		for i in range(self.numDrops):
			bean = self.beanClass(self.suit.air)
			bean.generateWithRequired(self.suit.zoneId)
			bean.setValue(self.value)
			bean.d_setX(self.suit.getX(render))
			bean.d_setY(self.suit.getY(render))
			bean.d_setZ(self.suit.getZ(render))
			if self.numDrops > 1 and i > 0:
				bean.d_setX(random.uniform(-5.0, 5.0))
				bean.d_setY(random.uniform(-5.0, 5.0))
			bean.b_setParent(CIGlobals.SPRender)
				
	def cleanup(self):
		self.suit = None
		self.value = None
		self.numDrops = None
		self.beanClass = None
