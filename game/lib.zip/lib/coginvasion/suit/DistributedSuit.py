# Filename: DistributedSuit.py
# Created by:  blach (02Nov14)

from panda3d.core import *
from direct.distributed.DistributedSmoothNode import DistributedSmoothNode
from direct.directnotify.DirectNotifyGlobal import directNotify
from lib.coginvasion.avatar.DistributedAvatar import DistributedAvatar
from direct.distributed import DelayDelete
from lib.coginvasion.globals import CIGlobals
from lib.coginvasion.suit.Suit import Suit
from direct.interval.IntervalGlobal import SoundInterval
from direct.distributed.DelayDeletable import DelayDeletable
from direct.distributed.ClockDelta import globalClockDelta

class DistributedSuit(Suit, DistributedAvatar, DistributedSmoothNode, DelayDeletable):
	notify = directNotify.newCategory("DistributedSuit")

	def __init__(self, cr):
		try:
			self.DistributedSuit_initialized
			return
		except:
			self.DistributedSuit_initialized = 1
		Suit.__init__(self)
		DistributedAvatar.__init__(self, cr)
		DistributedSmoothNode.__init__(self, cr)
		# These are just default values, we'll set them later on.
		self.anim = None
		self.state = "alive"
		self.health = None
		self.type = None
		self.team = None
		self.head = None
		self.skeleton = 0
		self.battle = None
		return
		
	def setBattle(self, battle):
		self.battle = battle
		
	def getBattle(self):
		return self.battle
		
	def printPos(self, task):
		print self.getPos(render)
		print self.getHpr(render)
		return task.cont
		
	def announceHealth(self, level, hp):
		DistributedAvatar.announceHealth(self, level, hp)
		if level == 1:
			healthSfx = self.audio3d.loadSfx("phase_3/audio/sfx/health.mp3")
			self.audio3d.attachSoundToObject(healthSfx, self)
			SoundInterval(healthSfx).start()
			del healthSfx
		
	def setSuit(self, suitType, head, team, skeleton):
		for obj in self.cr.doId2do.values():
			if obj.zoneId == self.zoneId:
				if obj.__class__.__name__ == "DistributedCogBattle":
					# This has to be the Cog Battle we're in because it's in the same zone.
					self.setBattle(obj)
		hp = CIGlobals.SuitHealthAmounts[head]
		Suit.generateSuit(self, suitType, head, team, hp, skeleton)
		
	def getSuit(self):
		return tuple((self.type, self.head, self.team, self.skeleton))
		
	def setName(self, name):
		Suit.setName(self, name, self.head)
		
	def setHealth(self, health):
		DistributedAvatar.setHealth(self, health)
		self.updateHealthBar(health)
		
	def setAnimState(self, anim, timestamp = None):
		self.anim = anim
		
		if timestamp == None:
			ts = 0.0
		else:
			ts = globalClockDelta.localElapsedTime(timestamp)
		
		if self.animFSM.getStateNamed(anim):
			self.animFSM.request(anim, [ts])
		
	def doAttack(self, attackName, timestamp = None):
		if timestamp == None:
			ts = 0.0
		else:
			ts = globalClockDelta.localElapsedTime(timestamp)
		self.animFSM.request('attack', [attackName, ts])
		
	def throwObject(self):
		self.acceptOnce("enter" + self.wsnp.node().getName(), self.__handleWeaponCollision)
		Suit.throwObject(self)
		
	def __handleWeaponCollision(self, entry):
		self.sendUpdate('toonHitByWeapon', [self.attack, base.localAvatar.doId])
		base.localAvatar.handleHitByWeapon(self.attack, self)
		self.b_handleWeaponTouch()
		
	def b_handleWeaponTouch(self):
		self.sendUpdate('handleWeaponTouch', [])
		self.handleWeaponTouch()
		
	def announceGenerate(self):
		DistributedAvatar.announceGenerate(self)
		if self.animFSM.getCurrentState().getName() == 'off':
			self.setAnimState('neutral')
			
	def generate(self):
		DistributedAvatar.generate(self)
		DistributedSmoothNode.generate(self)
		self.startSmooth()
		
	def disable(self):
		if self.suitTrack != None:
			self.suitTrack.finish()
			DelayDelete.cleanupDelayDeletes(self.suitTrack)
			self.suitTrack = None
		self.stopSmooth()
		self.anim = None
		self.state = None
		self.health = None
		self.type = None
		self.team = None
		self.head = None
		self.skeleton = None
		self.battle = None
		Suit.disable(self)
		DistributedAvatar.disable(self)
		
	def delete(self):
		Suit.delete(self)
		DistributedAvatar.delete(self)
		DistributedSmoothNode.delete(self)
		
