# Filename: DistributedPieTurretManager.py
# Created by:  blach (14Jun15)

from direct.directnotify.DirectNotifyGlobal import directNotify
from direct.distributed.DistributedObject import DistributedObject
from direct.gui.DirectGui import DirectButton, DirectFrame, DirectLabel, DirectWaitBar, OnscreenImage

from lib.coginvasion.globals import CIGlobals

class DistributedPieTurretManager(DistributedObject):
	notify = directNotify.newCategory("DistributedPieTurretManager")
	
	def __init__(self, cr):
		try:
			self.DistributedPieTurretManager_initialized
			return
		except:
			self.DistributedPieTurretManager_initialized = 1
		DistributedObject.__init__(self, cr)
		self.myTurret = None
		self.guiFrame = None
		self.guiLabel = None
		self.guiBar = None
		self.guiBg = None
		
	def d_requestPlace(self, poshpr):
		self.sendUpdate("requestPlace", [poshpr])
		
	def turretPlaced(self, turretId):
		self.myTurret = self.cr.doId2do.get(turretId)
		self.makeGui()
		
	def yourTurretIsDead(self):
		self.destroyGui()
		self.myTurret = None
		if base.localAvatar.getPUInventory()[0] > 0:
			self.createTurretButton()
		
	def makeGui(self):
		self.guiFrame = DirectFrame(parent = base.a2dBottomRight, pos=(-0.55, 0, 0.15))
		self.guiBg = OnscreenImage(image = "phase_4/maps/turret_gui_bg.png", scale = (0.15, 0, 0.075), parent = self.guiFrame)
		self.guiBg.setTransparency(True)
		self.guiLabel = DirectLabel(text = "Turret", text_fg = (1, 0, 0, 1), relief = None, text_scale = 0.05, text_font = loader.loadFont("phase_3/models/fonts/ImpressBT.ttf"), pos = (0, 0, 0.025), parent = self.guiFrame)
		self.guiBar = DirectWaitBar(range = self.myTurret.getMaxHealth(), value = self.myTurret.getHealth(), scale = 0.125, parent = self.guiFrame, pos = (0, 0, -0.01))
	
	def updateTurretGui(self):
		self.guiBar.update(self.myTurret.getHealth())
		
	def destroyGui(self):
		self.guiBar.destroy()
		self.guiBar = None
		self.guiLabel.destroy()
		self.guiLabel = None
		self.guiBg.destroy()
		self.guiBg = None
		self.guiFrame.destroy()
		self.guiFrame = None
		
	def createTurretButton(self):
		self.makeTurretBtn = DirectButton(relief = None, geom = CIGlobals.getDefaultBtnGeom(), text = "Turret", text_scale = 0.055, command = self.handleMakeTurretBtn, pos = (-0.55, 0, 0.15), parent = base.a2dBottomRight)
		
	def handleMakeTurretBtn(self):
		self.makeTurretBtn.destroy()
		del self.makeTurretBtn
		x, y, z = base.localAvatar.getPos()
		h, p, r = base.localAvatar.getHpr()
		self.d_requestPlace([x, y, z, h, p, r])
		base.localAvatar.sendUpdate('usedPU', [0])
		
	def __pollMyBattle(self, task):
		if base.localAvatar.getMyBattle():
			base.localAvatar.getMyBattle().setTurretManager(self)
			if base.localAvatar.getPUInventory()[0] > 0:
				self.createTurretButton()
			return task.done
		return task.cont
		
	def announceGenerate(self):
		DistributedObject.announceGenerate(self)
		taskMgr.add(self.__pollMyBattle, "__pollMyBattle")
		
	def disable(self):
		taskMgr.remove("__pollMyBattle")
		if hasattr(self, 'makeTurretBtn'):
			self.makeTurretBtn.destroy()
			del self.makeTurretBtn
		if self.myTurret:
			self.destroyGui()
			self.myTurret = None
		if base.localAvatar.getMyBattle():
			base.localAvatar.getMyBattle().setTurretManager(None)
		DistributedObject.disable(self)
