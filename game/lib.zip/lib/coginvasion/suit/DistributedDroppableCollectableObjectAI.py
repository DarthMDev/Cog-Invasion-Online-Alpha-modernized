"""

  Filename: DistributedDroppableCollectableObjectAI.py
  Created by: blach (22Mar15)

"""

from direct.directnotify.DirectNotifyGlobal import directNotify
from direct.distributed.DistributedNodeAI import DistributedNodeAI

class DistributedDroppableCollectableObjectAI(DistributedNodeAI):
	notify = directNotify.newCategory("DistributedDroppableCollectableObjectAI")
	
	def __init__(self, air):
		DistributedNodeAI.__init__(self, air)
		
	def collectedObject(self):
		self.requestDelete()
