# Filename: EagleGameGlobals.py
# Created by:  blach (08Jul15)

EAGLE_HIT_EVENT = 'DEagleSuit-hitByLocalToon'
