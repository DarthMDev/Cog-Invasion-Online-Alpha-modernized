# Filename: FinalScore.py
# Created by:  blach (29Jan15)

class FinalScore:

	def __init__(self, avId, score):
		self.avId = avId
		self.score = score
