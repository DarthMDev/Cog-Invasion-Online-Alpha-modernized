# Filename: DistributedEagleSuitAI.py
# Created by:  blach (08Jul15)

from direct.directnotify.DirectNotifyGlobal import directNotify
from direct.interval.IntervalGlobal import LerpPosInterval, Sequence, Wait, Func

from lib.coginvasion.npc.NPCWalker import NPCWalkInterval
from lib.coginvasion.globals import CIGlobals
from lib.coginvasion.suit.DistributedSuitAI import DistributedSuitAI

import random

class DistributedEagleSuitAI(DistributedSuitAI):
    notify = directNotify.newCategory("DistributedEagleSuitAI")

    def __init__(self, air):
        DistributedSuitAI.__init__(self, air)
        self.type = "A"
        self.team = "l"
        self.head = "legaleagle"
        self.name = CIGlobals.SuitNames[self.head]
        self.mg = None
        self.flyTrack = None
        self.currentFlyPoint = None

    def setMinigame(self, mg):
        self.mg = mg

    def getMinigame(self):
        return self.mg

    def handleGotHit(self):
        self.b_setAnimState('flail')
        if self.flyTrack:
            self.ignore(self.flyTrack.getDoneEvent())
            self.flyTrack.pause()
            self.flyTrack = None
        self.sendUpdate('fallAndExplode', [])
        self.flyTrack = Sequence(
            LerpPosInterval(
                self,
                duration = 4.0,
                pos = self.getPos(render) - (0, 0, 75),
                startPos = self.getPos(render),
                blendType = 'easeIn'
            ),
            Wait(1.5),
            Func(self.killMe)
        )
        self.flyTrack.start()

    def killMe(self):
        self.disable()
        self.requestDelete()

    def spawn(self):
        # spawn() also exists in DistributedSuitAI, but we're not doing
        # anything that a normal suit would do here, so don't even call
        # DistributedSuitAI.spawn.

        if not self.getMinigame():
            self.notify.error("Tried to spawn before self.mg was set!")

        point = random.choice(self.getMinigame().eagleFlyPoints)
        self.setPos(point)

        self.b_setAnimState('flyNeutral')
        self.createFlyPath()
        self.b_setParent(CIGlobals.SPRender)
        self.d_clearSmoothing()
        self.d_broadcastPosHpr()

    def createFlyPath(self):
        if self.flyTrack:
            self.ignore(self.flyTrack.getDoneEvent())
            self.flyTrack.pause()
            self.flyTrack = None
        point = random.choice(self.getMinigame().eagleFlyPoints)
        if self.currentFlyPoint == point:
            self.createFlyPath()
            return
        self.flyTrack = NPCWalkInterval(self, point,
            durationFactor = self.getMinigame().Round2EagleSpeed[self.getMinigame().getRound()],
            startPos = self.getPos(render), fluid = 1, name = self.uniqueName('DEagleSuitAI-flyTrack'))
        self.flyTrack.setDoneEvent(self.flyTrack.getName())
        self.acceptOnce(self.flyTrack.getDoneEvent(), self.createFlyPath)
        self.flyTrack.start()
        self.currentFlyPoint = point

    def delete(self):
        del self.currentFlyPoint
        del self.mg
        if self.flyTrack:
            self.ignore(self.flyTrack.getDoneEvent())
            self.flyTrack.pause()
            self.flyTrack = None
        DistributedSuitAI.delete(self)
