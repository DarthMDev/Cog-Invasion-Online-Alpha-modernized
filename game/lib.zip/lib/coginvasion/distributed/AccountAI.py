"""

  Filename: AccountAI.py
  Created by: blach (10Dec14)

"""

from direct.distributed.DistributedObjectAI import DistributedObjectAI

class AccountAI(DistributedObjectAI):
	
	def __init__(self, air):
		pass
