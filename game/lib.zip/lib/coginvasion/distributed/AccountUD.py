"""

  Filename: AccountUD.py
  Created by: blach (10Dec14)

"""

from direct.distributed.DistributedObjectUD import DistributedObjectUD

class AccountUD(DistributedObjectUD):
	
	def __init__(self, air):
		pass
