"""
  
  Filename: DistributedRoot.py
  Created by: blach (04Dec14)
  
"""

from direct.distributed.DistributedObject import DistributedObject

class DistributedRoot(DistributedObject):
	pass
