"""

  Filename: DistributedDistrictUD.py
  Created by: blach (14Dec14)

"""

from direct.distributed.DistributedObjectUD import DistributedObjectUD

class DistributedDistrictUD(DistributedObjectUD):
	
	def setAvailable(self, available):
		pass
