"""

  Filename: Account.py
  Created by: blach (10Dec14)

"""

from direct.distributed.DistributedObject import DistributedObject

class Account(DistributedObject):
	
	def __init__(self, cr):
		pass
