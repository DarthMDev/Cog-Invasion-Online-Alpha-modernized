"""

  Filename: DistributedToon.py
  Created by: blach (17June14)

"""

from lib.coginvasion.online.OnlineGlobals import DirectNotify
from lib.coginvasion.toon import Toon
from lib.coginvasion.avatar.DistributedAvatar import DistributedAvatar
from lib.coginvasion.gags.backpack import BackpackManager
from lib.coginvasion.gags import GagGlobals
from lib.coginvasion.globals import CIGlobals
from direct.distributed.DistributedSmoothNode import DistributedSmoothNode
from direct.distributed.ClockDelta import globalClockDelta
from direct.distributed.DelayDeletable import DelayDeletable
from direct.distributed import DelayDelete
from direct.interval.SoundInterval import SoundInterval
from direct.interval.IntervalGlobal import Sequence, Wait, Func
from panda3d.core import Point3
import random
import numbers
import types

notify = DirectNotify().newCategory("DistributedToon")

class DistributedToon(Toon.Toon, DistributedAvatar, DistributedSmoothNode, DelayDeletable):

    def __init__(self, cr):
        try:
            self.DistributedToon_initialized
            return
        except:
            self.DistributedToon_initialized = 1
        Toon.Toon.__init__(self, cr)
        DistributedAvatar.__init__(self, cr)
        DistributedSmoothNode.__init__(self, cr)
        self.token = -1
        self.ghost = 0
        self.puInventory = []
        self.equippedPU = -1
        self.backpackId = None
        self.backpack = None
        self.animState2animId = {}
        animId = 0
        for state in self.animFSM.getStates():
            self.animState2animId[state.getName()] = animId
            animId += 1
        del animId
        self.animId2animState = {v: k for k, v in self.animState2animId.items()}
        self.initAmmo = []
        self.initGagIds = []
        return

    def setEquippedPU(self, index):
        self.equippedPU = index

    def getEquippedPU(self):
        return self.equippedPU

    def setPUInventory(self, array):
        self.puInventory = array

    def getPUInventory(self):
        return self.puInventory

    def setGhost(self, value):
        self.ghost = value
        if value:
            self.ghostOn()
        else:
            self.ghostOff()

    def d_setGhost(self, value):
        self.sendUpdate("setGhost", [value])

    def b_setGhost(self, value):
        self.d_setGhost(value)
        self.setGhost(value)

    def getGhost(self):
        return self.ghost

    def setDNAStrand(self, dnaStrand):
        Toon.Toon.setDNAStrand(self, dnaStrand)

    def d_setDNAStrand(self, dnaStrand):
        self.sendUpdate("setDNAStrand", [dnaStrand])

    def b_setDNAStrand(self, dnaStrand):
        self.setDNAStrand(dnaStrand)
        self.d_setDNAStrand(dnaStrand)

    def lookAtObject(self, h, p, r, blink=1):
        if self.getPart('head').getHpr() == (h, p, r):
            return
        Toon.Toon.lerpLookAt(self, self.getPart('head'), tuple((h, p, r)))
        if blink:
            maxBlinks = random.randint(1, 2)
            numBlinks = 0
            delay = 0
            for blink in range(maxBlinks):
                if numBlinks == 0:
                    taskMgr.add(self.doBlink, "blinkOnTurn")
                else:
                    delay += 0.2
                    taskMgr.doMethodLater(delay, self.doBlink, "doBlink")
                numBlinks += 1
                
    def toonUp(self):
        pass

    def b_lookAtObject(self, h, p, r, blink=1):
        self.d_lookAtObject(h, p, r, blink)
        self.lookAtObject(h, p, r, blink)

    def d_lookAtObject(self, h, p, r, blink=1):
        self.sendUpdate('lookAtObject', [h, p, r, blink])

    def setChat(self, chat):
        Toon.Toon.setChat(self, chat)

    def gagCollision(self):
        self.backpack.getCurrentGag().doCollision()

    def b_gagCollision(self):
        self.sendUpdate("gagCollision", [])
        self.gagCollision()

    def gagActivate(self):
        self.backpack.getCurrentGag().activate()

    def b_gagActivate(self):
        self.sendUpdate("gagActivate", [])
        self.gagActivate()
        
    def setDropLoc(self, x, y, z):
        self.backpack.getCurrentGag().setEndPos(x, y, z)

    def tntExplode(self):
        self.pies.tntExplode()

    def b_tntExplode(self):
        self.sendUpdate("tntExplode", [])
        self.tntExplode()
        
    #def suitHitByPie(self, avId, gag_id):
        #suit = self.cr.doId2do.get(avId, None)
        # Disabled charring
        #Sequence(Func(suit.setColorScale, Vec4(0.2, 0.2, 0.2, 1)), Wait(2), Func(suit.setColorScale, Vec4(1, 1, 1, 1))).start()

    def setGagPos(self, x, y, z):
        pos = Point3(x, y, z)
        gag = self.backpack.getCurrentGag().getGag()
        if gag:
            gag.setPos(pos)

    def gagStart(self):
        if self.backpack.getCurrentGag(): self.backpack.getCurrentGag().start()

    def b_gagStart(self):
        self.sendUpdate("gagStart", [])
        self.gagStart()

    def gagThrow(self):
        if self.backpack.getCurrentGag(): self.backpack.getCurrentGag().throw()

    def b_gagThrow(self):
        self.sendUpdate("gagThrow", [])
        self.gagThrow()

    def gagRelease(self, gag_id):
        if self.backpack.getCurrentGag(): self.backpack.getCurrentGag().release()

    def b_gagRelease(self, gag_id):
        self.sendUpdate("gagRelease", [gag_id])
        self.gagRelease(gag_id)
        
    def setSplatPos(self, index, x, y, z):
        splatGag = None
        for gag in self.backpack.getGags():
            if gag.getID() == index:
                splatGag = gag
                break
        if not splatGag:
            return
        splatGag.setSplatPos(x, y, z)
        
    def d_setSplatPos(self, index, x, y, z):
        self.sendUpdate('setSplatPos', [index, x, y, z])
        
    def gagBuild(self):
        self.backpack.getCurrentGag().build()
        
    def b_gagBuild(self):
        self.gagBuild()
        self.sendUpdate('gagBuild', [])
        
    def handleSuitAttack(self, attack_id, suit_id):
        attack = CIGlobals.SuitAttacks[attack_id]
        suit = self.cr.doId2do.get(suit_id, None)
        if attack == "canned":
            sfx = base.loadSfx("phase_5/audio/sfx/SA_canned_impact_only.mp3")
            SoundInterval(sfx).start()
        elif attack == "playhardball":
            sfx = base.loadSfx("phase_5/audio/sfx/SA_hardball_impact_only_alt.mp3")
            SoundInterval(sfx).start()
        elif attack == "clipontie":
            sfx = base.loadSfx("phase_5/audio/sfx/SA_powertie_impact.mp3")
            SoundInterval(sfx).start()
        if not self.isDead():
            animToPlay = None
            timeToWait = 3.0
            if not attack in ["pickpocket", "fountainpen"]:
                suitH = suit.getH(render) % 360
                myH = self.getH(render) % 360
                if -90.0 <= (suitH - myH) <= 90.0:
                    animToPlay = "fallFWD"
                else:
                    animToPlay = "fallBCK"
            elif attack in ["pickpocket"]:
                animToPlay = "cringe"
            elif attack in ["fountainpen"]:
                animToPlay = "conked"
                timeToWait = 5.0
                self.getPart("head").setColorScale(0, 0, 0, 1)
                Sequence(Wait(3.0), Func(self.resetHeadColor)).start()
            if base.localAvatar.doId == self.doId:
                self.cr.playGame.getPlace().fsm.request('stop')
                self.b_setAnimState(animToPlay)
                Sequence(Wait(timeToWait), Func(self.fallDone)).start()
            
    def resetHeadColor(self):
        self.getPart('head').setColorScale(1, 1, 1, 1)
        
    def fallDone(self):
        self.cr.playGame.hood.loader.place.fsm.request('walk')
        self.b_setAnimState('neutral')
            
    def b_handleSuitAttack(self, attack_id, suit_id):
        self.handleSuitAttack(attack_id, suit_id)
        self.b_lookAtObject(0, 0, 0, blink = 1)
        self.sendUpdate('handleSuitAttack', [attack_id, suit_id])

    def equip(self, gag_id):
        self.backpack.setCurrentGag(GagGlobals.getGagByID(gag_id))
        
    def b_equip(self, gag_id):
        self.equip(gag_id)
        self.sendUpdate('equip', [gag_id])

    def setBackpack(self, backpack):
        if not isinstance(backpack, numbers.Number):
            self.backpack = backpack
        else:
            self.backpackId = backpack
            self.backpack = BackpackManager.getBackpack(backpack)
        if self.initAmmo:
            self.setBackpackAmmo(self.initGagIds, self.initAmmo)
        self.backpack.setup(self)
        Toon.Toon.backpack = self.backpack

    def b_setBackpack(self, backpackId):
        self.d_setBackpack(backpackId)
        self.setBackpack(BackpackManager.getBackpack(backpackId))

    def getBackpack(self):
        return self.backpack
    
    def buildAmmoList(self, gagIds):
        ammoList = []
        for index in range(len(gagIds)):
            gagId = gagIds[index]
            amt = self.backpack.getSupply(GagGlobals.getGagByID(gagId))
            ammoList.append(amt)
        return ammoList

    def setBackpackAmmo(self, gagIds, ammoList):
        if -1 in ammoList: return
        if not self.initAmmo:
            self.initAmmo = ammoList
            self.initGagIds = gagIds
        for index in range(len(ammoList)):
            amt = ammoList[index]
            gagId = gagIds[index]
            self.backpack.setSupply(amt, GagGlobals.getGagByID(gagId))
        if self.backpack.gagGUI: self.backpack.gagGUI.update()
        
    def updateBackpackAmmo(self):
        gagIds = []
        ammoList = []
        for gag in self.backpack.getGags():
            gagIds.append(GagGlobals.getIDByName(gag.getName()))
            ammoList.append(self.backpack.getSupply(gag.getName()))
        self.setBackpackAmmo(gagIds, ammoList)

    def setMoney(self, money):
        self.money = money

    def getMoney(self):
        return self.money

    def setAdminToken(self, value):
        self.token = value
        if value > -1:
            # Put an icon over my head.
            Toon.Toon.setAdminToken(self, value)
        else:
            Toon.Toon.removeAdminToken(self)

    def getAdminToken(self):
        return self.token

    def setAnimState(self, anim, timestamp = None, callback = None, extraArgs = []):
        self.anim = anim
        if timestamp == None:
            ts = 0.0
        else:
            ts = globalClockDelta.localElapsedTime(timestamp)

        if type(anim) == types.IntType:
            anim = self.animId2animState[anim]
        if self.animFSM.getStateNamed(anim):
            self.animFSM.request(anim, [ts, callback, extraArgs])

    def b_setAnimState(self, anim):
        self.d_setAnimState(anim)
        self.setAnimState(anim, None)

    def d_setAnimState(self, anim):
        if type(anim) == types.StringType:
            anim = self.animState2animId[anim]
        timestamp = globalClockDelta.getFrameNetworkTime()
        self.sendUpdate("setAnimState", [anim, timestamp])

    def getAnimState(self):
        return self.anim

    def setName(self, name):
        Toon.Toon.setName(self, name)
        if self.cr.isShowingPlayerIds:
            self.showAvId()

    def d_setName(self, name):
        self.sendUpdate('setName', [name])

    def b_setName(self, name):
        self.d_setName(name)
        self.setName(name)

    def showAvId(self):
        self.setDisplayName(self.getName() + "\n" + str(self.doId))

    def showName(self):
        self.setDisplayName(self.getName())

    def setDisplayName(self, name):
        self.setupNameTag(tempName = name)

    def wrtReparentTo(self, parent):
        DistributedSmoothNode.wrtReparentTo(self, parent)

    def announceHealthAndPlaySound(self, level, hp):
        DistributedAvatar.announceHealth(self, level, hp)
        hpSfx = self.audio3d.loadSfx("phase_11/audio/sfx/LB_toonup.mp3")
        self.audio3d.attachSoundToObject(hpSfx, self)
        SoundInterval(hpSfx).start()
        del hpSfx

    def announceGenerate(self):
        DistributedAvatar.announceGenerate(self)
        if self.animFSM.getCurrentState().getName() == 'off':
            self.setAnimState('neutral')
        self.startBlink()

    def generate(self):
        DistributedAvatar.generate(self)
        DistributedSmoothNode.generate(self)
        self.startSmooth()

    def disable(self):
        if self.track != None:
            self.track.finish()
            DelayDelete.cleanupDelayDeletes(self.track)
            self.track = None
        self.stopBlink()
        self.ignore('showAvId')
        self.ignore('showName')
        self.token = None
        Toon.Toon.disable(self)
        DistributedAvatar.disable(self)

    def delete(self):
        try:
            self.DistributedToon_deleted
        except:
            self.DistributedToon_deleted = 1
            self.stopSmooth()
            Toon.Toon.delete(self)
            DistributedAvatar.delete(self)
            DistributedSmoothNode.delete(self)
        return
