"""

  Filename: SuitBehaviorBase.py
  Created by: DecodedLogic (02Sep15)

"""

from direct.fsm.StateData import StateData

class SuitBehaviorBase(StateData):
    
    def __init__(self, suit):
        StateData.__init__(self, doneEvent = 'suit%s-behaviorDone' % (suit.doId))
        self.suit = suit
        
    def shouldStart(self):
        pass
    
    def isActive(self):
        return self.isEntered