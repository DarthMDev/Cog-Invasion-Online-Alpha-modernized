"""

  Filename: SuitPanicBehavior.py
  Created by: DecodedLogic (02Sep15)

"""

from lib.coginvasion.cog.SuitPathBehavior import SuitPathBehavior

class SuitPanicBehavior(SuitPathBehavior):
    RUNAWAY_SPEED = 0.1
    RUNAWAY_SAFE_DISTANCE = 50
    
    def __init__(self, suit):
        SuitPathBehavior.__init__(self, suit)
        self.toonsInRange = []
        self.isPanicked = False
        self.closestToon = None
        self.runAwayTaskName = self.suit.uniqueName('runAway')
        
    def enter(self):
        SuitPathBehavior.enter(self)
        # Let's get out of here!
        self.createPath(durationFactor = self.RUNAWAY_SPEED, fromCurPos = True)
        self.isPanicked = True
        
        # Let's get away from the closest toon.
        self.closestToon = self.getClosestToon()
        taskMgr.add(self.__runAway, self.runAwayTaskName)
        
    def exit(self):
        SuitPathBehavior.exit(self)
        taskMgr.remove(self.runAwayTaskName)
        self.toonsInRange = []
        self.isPanicked = False
        self.closestToon = None
        
    def __runAway(self, task):
        try:
            if self.suit.getDistance(self.closestToon) >= self.RUNAWAY_SAFE_DISTANCE:
                self.exit()
                return task.done
            elif self.walkTrack == None or self.walkTrack.isStopped():
                self.createPath(durationFactor = self.RUNAWAY_SPEED, fromCurPos = True)
            return task.cont
        except:
            self.exit()
            return task.done
        
    def shouldStart(self):
        weakLevel = 6
        toonRange = 15
        panicHealthPerct = 0.35
        
        if not self.isPanicked:
            self.toonsInRange = []
        
        # Let's search for toons in range.
        for av in self.suit.air.doId2do.values():
            if av.__class__.__name__ == 'DistributedToonAI':
                if av.zoneId == self.suit.zoneId:
                    if self.suit.getDistance(av) <= toonRange:
                        self.toonsInRange.append(av)
        
        healthPerct = (self.suit.getHealth() / self.suit.getMaxHealth())
        """
        if self.suit.getLevel() <= weakLevel and len(self.toonsInRange) >= 2:
            return True
        elif self.suit.getLevel() > weakLevel and healthPerct <= panicHealthPerct and len(self.toonsInRange) > 0:
            return True
        """
        if len(self.toonsInRange) > 0:
            return True
        self.toonsInRange = []
        return False
    
    def getClosestToon(self):
        distances = []
        for toon in self.toonsInRange:
            distances.append(toon.getDistance(self.suit))
        distances.sort()
        for i in range(len(self.toonsInRange)):
            toon = self.toonsInRange[i]
            if toon.getDistance(self.suit) == distances[0]:
                return toon