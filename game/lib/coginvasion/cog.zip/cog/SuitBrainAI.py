"""

  Filename: SuitBrainAI.py
  Created by: DecodedLogic (03Sep15)

"""

from direct.showbase.DirectObject import DirectObject
from lib.coginvasion.cog.SuitHabitualBehavior import SuitHabitualBehavior
from lib.coginvasion.cog.SuitPathBehavior import SuitPathBehavior
from direct.task.Task import Task
import operator

class SuitBrain(DirectObject):
    
    def __init__(self, suit):
        self.suit = suit
        self.behaviors = []
        self.currentBehavior = None
        self.thinkTaskName = self.suit.uniqueName('think')
        
    def addBehavior(self, behavior, priority):
        self.behaviors.append([behavior, priority])
        self.organizeBehaviors()
        
    def removeBehavior(self, behavior):
        self.behaviors.remove(behavior)
        self.organizeBehaviors()
        
    def exitCurrentBehavior(self, forceClose = 0):
        if self.currentBehavior:
            self.currentBehavior.exit()
            if forceClose:
                if isinstance(self.currentBehavior, SuitPathBehavior):
                    self.currentBehavior.clearWalkTrack()
            self.currentBehavior = None
        
    def organizeBehaviors(self):
        behaviors = {}
        for behavior, priority in self.behaviors:
            behaviors[behavior] = priority
        sorted_behaviors = sorted(behaviors.items(), key = operator.itemgetter(1))
        self.behaviors = []
        for behaviorEntry in sorted_behaviors:
            behavior = behaviorEntry[0]
            self.behaviors.append(behavior)
    
    def startThinking(self):
        self.__think()
        taskMgr.add(self.__think, self.thinkTaskName)
        
    def stopThinking(self):
        taskMgr.remove(self.thinkTaskName)
        self.exitCurrentBehavior(forceClose = 1)
        
    def __think(self, task = None):
        if task:
            task.delayTime = 1
        if self.currentBehavior:
            if isinstance(self.currentBehavior, SuitHabitualBehavior) and self.currentBehavior.isActive():
                # This is a behavior that we can't override, we must wait until it completes.
                return Task.again
        for behavior in self.behaviors:
            if behavior.shouldStart():
                if isinstance(behavior, SuitPathBehavior) and isinstance(self.currentBehavior, SuitPathBehavior):
                    self.exitCurrentBehavior(forceClose = 1)
                else:
                    self.exitCurrentBehavior()
                behavior.enter()
                self.currentBehavior = behavior
                break
        if task:
            return Task.again