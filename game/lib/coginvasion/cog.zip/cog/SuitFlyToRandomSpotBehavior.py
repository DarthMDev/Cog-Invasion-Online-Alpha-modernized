"""

  Filename: SuitFlyToRandomSpotBehavior.py
  Created by: DecodedLogic (06Sep15)

"""

from lib.coginvasion.cog.SuitHabitualBehavior import SuitHabitualBehavior

class SuitFlyToRandomSpotBehavior(SuitHabitualBehavior):
    
    def __init__(self, suit):
        SuitHabitualBehavior.__init__(self, suit)
        
    def shouldStart(self):
        