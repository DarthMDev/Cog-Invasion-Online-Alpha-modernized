"""

  Filename: Voice.py
  Created by: DecodedLogic (31July14)

"""

class Voice:
    NORMAL, SKELETON, BOSS = range(3)
    
    paths = {
        NORMAL : 'phase_3.5/audio/dial/COG_VO_%s.mp3',
        SKELETON: 'phase_5/audio/sfx/Skel_COG_VO_%s.mp3',
        BOSS: 'phase_9/audio/sfx/Boss_COG_VO_%s.mp3'
    }
    
    def getSoundFile(self, voice, expression):
        path = self.paths.get(voice)
        return (path % expression)
    
    def getVoiceById(self, index):
        voices = [self.NORMAL, self.SKELETON, self.BOSS]
        return voices[index]