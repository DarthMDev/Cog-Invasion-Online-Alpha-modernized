"""

  Filename: Variant.py
  Created by: DecodedLogic (31July14)

"""


NORMAL, SKELETON, WAITER = range(3)

def getVariantById(index):
    variants = [NORMAL, SKELETON, WAITER]
    return variants[index]