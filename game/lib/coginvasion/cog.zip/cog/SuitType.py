"""

  Filename: SuitType.py
  Created by: DecodedLogic (31July14)

"""

class SuitType:
    A, B, C = 'A', 'B', 'C'