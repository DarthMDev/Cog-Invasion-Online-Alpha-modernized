"""

  Filename: SuitState.py
  Created by: DecodedLogic (01Sep14)

"""

class SuitState:
    ALIVE, LURED, DEAD = range(3)