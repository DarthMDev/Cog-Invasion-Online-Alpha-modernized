"""

  Filename: SuitBrainAI.py
  Created by: DecodedLogic (03Sep15)

"""

from direct.showbase.DirectObject import DirectObject
from lib.coginvasion.cog.SuitHabitualBehavior import SuitHabitualBehavior
from lib.coginvasion.cog.SuitPathBehavior import SuitPathBehavior
from direct.task.Task import Task
import operator

class SuitBrain(DirectObject):
    
    def __init__(self, suit):
        self.suit = suit
        self.behaviors = {}
        self.currentBehavior = None
        self.thinkTaskName = self.suit.uniqueName('think')
        
    def addBehavior(self, behavior, priority):
        self.behaviors.update({behavior : priority})
        behavior.load()
        self.organizeBehaviors()
        
    def removeBehavior(self, behavior):
        for iBehavior in self.behaviors.keys():
            if iBehavior == behavior:
                self.behaviors.remove(iBehavior)
                if self.currentBehavior == behavior:
                    self.exitCurrentBehavior()
        self.organizeBehaviors()
        
    def getBehavior(self, behaviorType):
        for behavior in self.behaviors.keys():
            if behavior.__class__ == behaviorType:
                return behavior
        
    def exitCurrentBehavior(self):
        if self.currentBehavior:
            self.currentBehavior.exit()
            if isinstance(self.currentBehavior, SuitPathBehavior):
                self.currentBehavior.clearWalkTrack()
            self.currentBehavior = None
        
    def organizeBehaviors(self):
        behaviors = {}
        for behavior, priority in self.behaviors.items():
            behaviors[behavior] = priority
        sorted_behaviors = sorted(behaviors.items(), key = operator.itemgetter(1))
        self.behaviors = {}
        for behaviorEntry in sorted_behaviors:
            behavior = behaviorEntry[0]
            priority = behaviorEntry[1]
            self.behaviors.update({behavior : priority})
    
    def startThinking(self, task = None):
        taskMgr.add(self.__think, self.thinkTaskName)
        if task:
            return Task.done
        
    def stopThinking(self):
        taskMgr.remove(self.thinkTaskName)
        self.exitCurrentBehavior()
        
    def __think(self, task = None):
        if task and self.currentBehavior:
            task.delayTime = 1
        if self.suit.isDead():
            self.exitCurrentBehavior()
            return Task.done
        if self.currentBehavior:
            if isinstance(self.currentBehavior, SuitHabitualBehavior) and self.currentBehavior.isActive():
                # This is a behavior that we can't override, we must wait until it completes.
                self.acceptOnce(self.currentBehavior.doneEvent, self.startThinking)
                return Task.done
        for behavior in self.behaviors.keys():
            if behavior.shouldStart():
                if behavior.isActive():
                    continue
                self.exitCurrentBehavior()
                behavior.enter()
                print '%s: Entering behavior.' % (self.suit.getName())
                self.currentBehavior = behavior
                break
        if task:
            return Task.again