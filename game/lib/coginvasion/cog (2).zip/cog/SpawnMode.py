"""

  Filename: SpawnMode.py
  Created by: DecodedLogic (02Sep14)

"""

class SpawnMode:
    FLYDOWN, FADEOUT, APPEAR = range(3)