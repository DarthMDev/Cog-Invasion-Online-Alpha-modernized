"""

  Filename: SuitFollowBossBehavior.py
  Created by: DecodedLogic (02Sep15)

"""

from lib.coginvasion.cog.SuitBehaviorBase import SuitBehaviorBase
from lib.coginvasion.globals import CIGlobals

class SuitFollowBossBehavior(SuitBehaviorBase):
    
    def __init__(self, suit, boss):
        SuitBehaviorBase.__init__(self, suit)
        self.boss = boss
        
    def enter(self):
        bossSpot = self.boss.boss.spot
        if not bossSpot:
            bossSpot = self.boss.getPos(render)
        else:
            bossSpot = CIGlobals.SuitSpawnPoints[self.suit.hood][bossSpot]
            
        if self.suit.currentPath == bossSpot:
            self.suit.createPath(path_key = bossSpot, fromCurPos = True)
        else:
            self.suit.currentPathQueue = Suit
            
    def shouldStart(self):
        if self.boss.getHealth() > 0:
            return True
        return False