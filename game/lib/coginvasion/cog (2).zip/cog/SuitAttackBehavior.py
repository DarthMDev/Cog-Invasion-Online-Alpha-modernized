"""

  Filename: SuitAttackBehavior.py
  Created by: DecodedLogic (13Sep15)

"""

from lib.coginvasion.cog.SuitHabitualBehavior import SuitHabitualBehavior
from lib.coginvasion.globals import CIGlobals
from lib.coginvasion.suit import SuitAttacks

from direct.distributed.ClockDelta import globalClockDelta
from direct.task.Task import Task
import random, operator
from lib.coginvasion.cog.SuitPanicBehavior import SuitPanicBehavior

class SuitAttackBehavior(SuitHabitualBehavior):
    
    ATTACK_DISTANCE = 40.0
    ATTACK_COOLDOWN = 10
    MAX_ATTACKERS = 3
    
    def __init__(self, suit):
        SuitHabitualBehavior.__init__(self, suit, doneEvent = 'suit%s-attackDone' % suit.doId)
        self.avatarsInRange = []
        self.maxAttacksPerSession = 3
        self.attacksThisSession = 0
        self.attacksDone = 0
        self.target = None
        
        level = self.suit.getLevel()
        if 1 <= level <= 5:
            self.maxAttacksPerSession = 3
        elif 5 <= level <= 10:
            self.maxAttacksPerSession = 4
        elif 9 <= level <= 12:
            self.maxAttacksPerSession = 5
        
    def enter(self):
        SuitHabitualBehavior.enter(self)
        self.attacksThisSession = 0
        self.startAttacking()
        print '%s sent attack message.' % (self.suit.getName())
        
    def exit(self):
        SuitHabitualBehavior.exit(self)
        
    def startAttacking(self, task = None):
        print '%s is attacking.' % (self.suit.getName())
        # Do we need to reset the avatars in-range?
        if self.attacksThisSession > 0:
            self.resetAvatarsInRange()
            
        # Stop attacking if low on health or if there's nothing around to attack.
        brain = self.suit.getBrain()
        if not brain:
            self.stopAttacking()
            return
        panicBehavior = brain.getBehavior(SuitPanicBehavior)
        healthPerct = float(self.suit.getHealth()) / float(self.suit.getMaxHealth())
        if len(self.avatarsInRange) < 1 or panicBehavior and healthPerct <= panicBehavior.getPanicHealthPercentage():
            self.stopAttacking()
            return
        
        # Let's select a target and look at them.
        target = self.avatarsInRange[0]
        self.suit.b_setAnimState('neutral')
        self.suit.headsUp(target)
        
        # Choose a random attack and start it.
        attack = random.choice(self.suit.suitPlan.getAttacks())
        attackIndex = SuitAttacks.SuitAttackLengths.keys().index(attack)
        attackTaunt = random.randint(0, len(CIGlobals.SuitAttackTaunts[attack]) - 1)
        timestamp = globalClockDelta.getFrameNetworkTime()
        if self.suit.isDead():
            self.stopAttacking()
            return
        self.suit.sendUpdate('doAttack', [attackIndex, target.doId, timestamp])
        self.suit.d_setChat(CIGlobals.SuitAttackTaunts[attack][attackTaunt])
        self.attacksThisSession += 1
        self.attacksDone += 1
        
        # Are we allowed to continue attacking?
        self.ATTACK_COOLDOWN = random.randint(6, 12)
        if self.attacksThisSession < self.maxAttacksPerSession:
            taskMgr.doMethodLater(self.ATTACK_COOLDOWN, self.startAttacking, self.suit.uniqueName('attackTask'))
            print '%s started attack task.' % (self.suit.getName())
        else:
            taskMgr.doMethodLater(self.ATTACK_COOLDOWN, self.stopAttacking, self.suit.uniqueName('finalAttack'))
            self.stopAttacking()
            print '%s completed attack behavior.' % (self.suit.getName())

        if task:
            return Task.done
        
    def stopAttacking(self, task = None):
        self.attacksThisSession = 0
        self.avatarsInRange = []
        self.ATTACK_COOLDOWN = random.randint(6, 12)
        self.exit()
        if task:
            return Task.done
        
    def resetAvatarsInRange(self):
        toonObjsInRange = {}
        self.avatarsInRange = []
        
        for obj in base.air.doId2do.values():
            className = obj.__class__.__name__
            if className in ['DistributedToonAI', 'DistributedPieTurretAI']:
                if obj.zoneId == self.suit.zoneId:
                    if not obj.isDead():
                        dist = obj.getDistance(self.suit)
                        if className == 'DistributedToonAI' and obj.getNumAttackers() >= self.MAX_ATTACKERS or className == 'DistributedToonAI' and obj.getGhost():
                            continue
                        if dist <= self.ATTACK_DISTANCE:
                            toonObjsInRange.update({obj : dist})
    
        toonObjsInRange = sorted(toonObjsInRange.items(), key = operator.itemgetter(1))
        for toonObj, _ in toonObjsInRange:
            self.avatarsInRange.append(toonObj)
        
    def shouldStart(self):
        self.resetAvatarsInRange()
            
        if len(self.avatarsInRange) > 0 and not self.isEntered:
            return True
        return False
    
    def getTarget(self):
        return self.target
    
    def getAttacksDone(self):
        return self.attacksDone